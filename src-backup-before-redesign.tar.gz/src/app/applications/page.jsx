"use client";

import Link from "next/link";
import React, { useEffect, useState } from "react";

const TYPE_STYLES = {
  FULL_TIME: "bg-blue-100 text-blue-800",
  PART_TIME: "bg-amber-100 text-amber-800",
  CONTRACT: "bg-orange-100 text-orange-800",
  INTERNSHIP: "bg-purple-100 text-purple-800",
};

const STATUS_STYLES = {
  PENDING: "bg-amber-100 text-amber-800",
  APPROVED: "bg-green-100 text-green-800",
  DECLINED: "bg-red-100 text-red-800",
};

function getTypeColor(type) {
  return TYPE_STYLES[type] || "bg-gray-100 text-gray-800";
}

function getStatusColor(status) {
  return STATUS_STYLES[status] || "bg-gray-100 text-gray-800";
}

export default function ApplicationsPage() {
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [withdrawingId, setWithdrawingId] = useState(null);

  const fetchApplications = async () => {
    setLoading(true);
    setError("");

    try {
      const res = await fetch("/api/applications");
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Error fetching applications");

      setApplications(data.data || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchApplications();
  }, []);

  const handleWithdraw = async (jobId) => {
    if (!confirm("Withdraw this application?")) return;

    setWithdrawingId(jobId);

    try {
      const res = await fetch(`/api/jobs/${jobId}/apply`, {
        method: "DELETE",
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Error withdrawing application");

      setApplications((prev) => prev.filter((a) => a.jobId !== jobId));
    } catch (err) {
      alert(err.message);
    } finally {
      setWithdrawingId(null);
    }
  };

  const counts = applications.reduce(
    (acc, a) => {
      acc[a.status] = (acc[a.status] || 0) + 1;
      return acc;
    },
    { PENDING: 0, APPROVED: 0, DECLINED: 0 },
  );

  return (
    <div className="max-w-5xl mx-auto p-4 md:p-6">
      <div className="mb-8">
        <div className="flex items-center justify-between flex-wrap gap-4 mb-2">
          <h1 className="text-4xl font-bold text-white">My Applications</h1>
          <Link
            href="/jobs"
            className="px-4 py-1.5 text-sm rounded-lg font-medium bg-linear-to-r from-sky-500 to-blue-600 text-white hover:from-sky-400 hover:to-blue-500 shadow-lg shadow-sky-500/10"
          >
            Browse Jobs
          </Link>
        </div>
        {!loading && (
          <p className="text-gray-400">
            {applications.length} application{applications.length === 1 ? "" : "s"} •{" "}
            <span className="text-amber-400">{counts.PENDING} pending</span>,{" "}
            <span className="text-green-400">{counts.APPROVED} approved</span>,{" "}
            <span className="text-red-400">{counts.DECLINED} declined</span>
          </p>
        )}
      </div>

      {error && (
        <div className="bg-red-500/10 border border-red-500/30 text-red-400 rounded-lg px-4 py-3 mb-6">
          ⚠️ {error}
        </div>
      )}

      {loading ? (
        <div className="flex flex-col gap-4">
          {[1, 2, 3].map((i) => (
            <div
              key={i}
              className="bg-slate-800/50 border border-slate-700 rounded-xl p-6 h-28 animate-pulse"
            />
          ))}
        </div>
      ) : applications.length === 0 ? (
        <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-12 text-center text-gray-400">
          <p className="text-lg mb-4">You haven&apos;t applied to any jobs yet.</p>
          <Link
            href="/jobs"
            className="inline-block px-4 py-1.5 text-sm rounded-lg font-medium bg-linear-to-r from-sky-500 to-blue-600 text-white hover:from-sky-400 hover:to-blue-500"
          >
            Browse open jobs
          </Link>
        </div>
      ) : (
        <div className="flex flex-col gap-4">
          {applications.map((app) => (
            <div
              key={app.id}
              className="bg-white border border-gray-200 rounded-xl shadow-sm hover:shadow-md transition-all p-6"
            >
              <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 mb-3">
                <div>
                  <h2 className="text-xl font-semibold text-black mb-1">
                    {app.job.title}
                  </h2>
                  <p className="text-gray-600">
                    {app.job.company} • {app.job.location}
                  </p>
                  {app.job.employer?.name && (
                    <p className="text-gray-400 text-xs mt-1">
                      Employer: {app.job.employer.name}
                    </p>
                  )}
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap ${getTypeColor(
                      app.job.type,
                    )}`}
                  >
                    {app.job.type.replace("_", " ")}
                  </span>
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap ${getStatusColor(
                      app.status,
                    )}`}
                  >
                    {app.status}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm mb-4">
                <div>
                  <p className="text-gray-500">Years of Experience</p>
                  <p className="text-black font-medium">{app.yearsOfExperience}</p>
                </div>
                <div>
                  <p className="text-gray-500">CV</p>
                  <a
                    href={app.cvUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sky-600 hover:underline font-medium"
                  >
                    📄 View CV
                  </a>
                </div>
              </div>

              <div className="flex items-center justify-between flex-wrap gap-3">
                <p className="text-gray-400 text-xs">
                  Applied {new Date(app.createdAt).toLocaleDateString()}
                </p>
                <button
                  onClick={() => handleWithdraw(app.jobId)}
                  disabled={withdrawingId === app.jobId}
                  className="px-3 py-1.5 text-sm rounded-lg font-medium text-red-600 hover:bg-red-50 cursor-pointer disabled:opacity-60"
                >
                  {withdrawingId === app.jobId ? "Withdrawing..." : "Withdraw"}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}