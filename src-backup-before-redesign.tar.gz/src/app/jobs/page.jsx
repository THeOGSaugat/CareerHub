"use client";

import Link from "next/link";
import React, { useCallback, useEffect, useState } from "react";

function ApplyModal({ job, onClose, onApplied }) {
  const [formData, setFormData] = useState({
    coverLetter: "",
    yearsOfExperience: "",
  });
  const [file, setFile] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [uploadStatus, setUploadStatus] = useState(""); // "" | "uploading" | "applying"
  const [error, setError] = useState("");

  const handleChange = (e) =>
    setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleFileChange = (e) => {
    const selected = e.target.files[0];
    setError("");

    if (!selected) {
      setFile(null);
      return;
    }
    if (selected.type !== "application/pdf") {
      setError("Only PDF files are allowed");
      e.target.value = "";
      setFile(null);
      return;
    }
    if (selected.size > 5 * 1024 * 1024) {
      setError("File too large. Max size is 5MB");
      e.target.value = "";
      setFile(null);
      return;
    }
    setFile(selected);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    if (!file) {
      setError("Please select your CV (PDF)");
      return;
    }

    setSubmitting(true);

    try {
      setUploadStatus("uploading");
      const uploadFormData = new FormData();
      uploadFormData.append("file", file);

      const uploadRes = await fetch("/api/upload", {
        method: "POST",
        body: uploadFormData,
      });
      const uploadData = await uploadRes.json();
      if (!uploadRes.ok) throw new Error(uploadData.error || "CV upload failed");

      const cvUrl = uploadData.data.url;

      setUploadStatus("applying");
      const res = await fetch(`/api/jobs/${job.id}/apply`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ ...formData, cvUrl }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Something went wrong");

      onApplied(job.id);
      onClose();
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
      setUploadStatus("");
    }
  };

  return (
    <div
      className="fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-50"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-xl shadow-xl max-w-lg w-full p-6"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between mb-4">
          <h3 className="text-xl font-semibold text-black">Apply to {job.title}</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 text-2xl leading-none cursor-pointer"
          >
            ×
          </button>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-lg px-3 py-2 mb-4">
            ⚠️ {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">CV / Resume (PDF, max 5MB) *</label>
            <input
              type="file"
              accept="application/pdf"
              onChange={handleFileChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-black text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 file:mr-3 file:py-1.5 file:px-3 file:rounded-md file:border-0 file:bg-sky-50 file:text-sky-600 file:cursor-pointer cursor-pointer"
            />
            {file && (
              <p className="text-xs text-gray-500 mt-1">
                Selected: {file.name} ({(file.size / 1024 / 1024).toFixed(2)} MB)
              </p>
            )}
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Years of Experience *</label>
            <input
              type="text"
              name="yearsOfExperience"
              required
              value={formData.yearsOfExperience}
              onChange={handleChange}
              placeholder="e.g. 2"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-black focus:outline-none focus:ring-2 focus:ring-sky-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Cover Letter *</label>
            <textarea
              name="coverLetter"
              required
              rows="5"
              value={formData.coverLetter}
              onChange={handleChange}
              placeholder="Tell them why you're a good fit..."
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-black focus:outline-none focus:ring-2 focus:ring-sky-500"
            />
          </div>
          <div className="flex gap-3 justify-end pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-1.5 text-sm rounded-lg font-medium text-gray-600 hover:bg-gray-100 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-4 py-1.5 text-sm rounded-lg font-medium bg-linear-to-r from-sky-500 to-blue-600 text-white hover:from-sky-400 hover:to-blue-500 cursor-pointer disabled:opacity-60"
            >
              {uploadStatus === "uploading"
                ? "Uploading CV..."
                : uploadStatus === "applying"
                  ? "Submitting..."
                  : "Submit Application"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

const Page = () => {
  const [jobs, setJobs] = useState([]);
  const [keyword, setKeyword] = useState("");
  const [type, setType] = useState("");
  const [sort, setSort] = useState("newest");
  const [userId, setUserId] = useState(null);
  const [applyJob, setApplyJob] = useState(null);
  const [withdrawingId, setWithdrawingId] = useState(null);
  const [savedIds, setSavedIds] = useState(new Set());
  const [savingId, setSavingId] = useState(null);

  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    if (storedUser) {
      try {
        setUserId(JSON.parse(storedUser).id);
      } catch {
        setUserId(null);
      }
    }

    const fetchSaved = async () => {
      try {
        const res = await fetch("/api/saved-jobs");
        const data = await res.json();
        if (res.ok) {
          setSavedIds(new Set((data.data || []).map((s) => s.jobId)));
        }
      } catch {
        // non-critical, bookmarks just won't pre-fill
      }
    };
    fetchSaved();
  }, []);

  const toggleSave = async (jobId) => {
    setSavingId(jobId);
    const alreadySaved = savedIds.has(jobId);

    try {
      const res = await fetch("/api/saved-jobs", {
        method: alreadySaved ? "DELETE" : "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ jobId }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Error updating saved jobs");

      setSavedIds((prev) => {
        const next = new Set(prev);
        alreadySaved ? next.delete(jobId) : next.add(jobId);
        return next;
      });
    } catch (err) {
      alert(err.message);
    } finally {
      setSavingId(null);
    }
  };

  const fetchJobs = useCallback(async (search = "", typeFilter = "", sortOption = "newest") => {
    try {
      const params = new URLSearchParams();
      if (search) params.set("search", search);
      if (typeFilter) params.set("type", typeFilter);
      if (sortOption) params.set("sort", sortOption);

      const res = await fetch(`/api/jobs?${params.toString()}`);
      const data = await res.json();
      if (!res.ok) throw new Error("Error fetching the job");

      setJobs(data.data);
    } catch (err) {
      console.log("Error caught: ", err);
    }
  }, []);

  useEffect(() => {
    fetchJobs(keyword, type, sort);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [type, sort]);

  const getTypeColor = (jobType) => {
    switch (jobType) {
      case "FULL_TIME":
        return "bg-blue-100 text-blue-800";
      case "INTERNSHIP":
        return "bg-purple-100 text-purple-800";
      case "PART_TIME":
        return "bg-amber-100 text-amber-800";
      case "CONTRACT":
        return "bg-orange-100 text-orange-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const hasApplied = (job) =>
    userId != null && job.applications?.some((a) => a.seekerId === userId);

  const handleApplied = (jobId) => {
    setJobs((prev) =>
      prev.map((j) =>
        j.id === jobId
          ? { ...j, applications: [...(j.applications || []), { seekerId: userId }] }
          : j,
      ),
    );
  };

  const handleWithdraw = async (jobId) => {
    setWithdrawingId(jobId);
    try {
      const res = await fetch(`/api/jobs/${jobId}/apply`, {
        method: "DELETE",
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Error withdrawing");

      setJobs((prev) =>
        prev.map((j) =>
          j.id === jobId
            ? { ...j, applications: (j.applications || []).filter((a) => a.seekerId !== userId) }
            : j,
        ),
      );
    } catch (err) {
      alert(err.message);
    } finally {
      setWithdrawingId(null);
    }
  };

  return (
    <div className="max-w-6xl mx-auto p-4 md:p-6">
      <div className="mb-8 flex flex-col md:flex-row justify-between items-start md:items-baseline gap-4">
        <div>
          <h1 className="text-4xl font-bold mb-2 text-white">Jobs</h1>
          <p className="text-gray-50">
            There are {jobs.length} active jobs actively looking for seekers
            just like you!
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
          <div className="flex">
            <input
              type="text"
              className="border-2 border-white rounded-l-lg p-2"
              placeholder="eg. React Developer"
              onChange={(e) => {
                setKeyword(e.target.value);
              }}
            />
            <button
              className="border-r-2 border-t-2 border-b-2 border-white rounded-r-lg p-2 cursor-pointer"
              onClick={() => {
                fetchJobs(keyword, type, sort);
              }}
            >
              🔍
            </button>
          </div>

          <select
            value={type}
            onChange={(e) => setType(e.target.value)}
            className="px-3 py-2 rounded-lg bg-slate-800 border-2 border-white text-white text-sm focus:outline-none"
          >
            <option value="">All Types</option>
            <option value="FULL_TIME">Full Time</option>
            <option value="PART_TIME">Part Time</option>
            <option value="CONTRACT">Contract</option>
            <option value="INTERNSHIP">Internship</option>
          </select>

          <select
            value={sort}
            onChange={(e) => setSort(e.target.value)}
            className="px-3 py-2 rounded-lg bg-slate-800 border-2 border-white text-white text-sm focus:outline-none"
          >
            <option value="newest">Newest First</option>
            <option value="oldest">Oldest First</option>
            <option value="salary_high">Salary: High to Low</option>
            <option value="salary_low">Salary: Low to High</option>
          </select>
        </div>
      </div>

      <div className="flex flex-col gap-4">
        {jobs.length === 0 ? (
          <div className="bg-gray-50 border border-gray-200 rounded-lg p-12 text-center text-gray-500">
            <p className="text-lg">There are no job listings at the moment</p>
          </div>
        ) : (
          jobs.map((job) => {
            const applied = hasApplied(job);
            return (
              <div
                key={job.id}
                className="bg-white border border-gray-200 rounded-xl shadow-sm hover:shadow-md transition-all overflow-hidden"
              >
                <div className="p-6">
                  <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 mb-4">
                    <div>
                      <h2 className="text-xl font-semibold mb-1 text-black">
                        {job.title}
                      </h2>
                      <p className="text-gray-600">
                        {job.company} • {job.location}
                      </p>
                    </div>
                    <div className="flex items-start gap-2">
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-medium ${getTypeColor(
                          job.type,
                        )}`}
                      >
                        {job.type.replace("_", " ")}
                      </span>
                      <button
                        onClick={() => toggleSave(job.id)}
                        disabled={savingId === job.id}
                        aria-label={savedIds.has(job.id) ? "Unsave job" : "Save job"}
                        title={savedIds.has(job.id) ? "Unsave job" : "Save job"}
                        className="text-xl leading-none cursor-pointer disabled:opacity-50"
                      >
                        {savedIds.has(job.id) ? "🔖" : "📑"}
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4 text-sm">
                    <div>
                      <p className="text-gray-500">Salary</p>
                      <p className="font-medium text-green-600">
                        {job.salary.toLocaleString()}
                      </p>
                    </div>
                    <div>
                      <p className="text-gray-500">Applications</p>
                      <p className="font-medium text-green-500">
                        {job.applications.length}
                      </p>
                    </div>
                    <div>
                      <p className="text-gray-500">Posted</p>
                      <p className="font-medium text-green-500">
                        {new Date(job.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>

                  <p className="text-gray-700 mb-4">{job.description}</p>

                  <div className="flex items-center gap-3">
                    <Link
                      href={`/jobs/${job.id}`}
                      className="px-4 py-1.5 text-sm rounded-lg font-medium text-sky-600 hover:bg-sky-50 cursor-pointer"
                    >
                      View Details
                    </Link>

                    {applied ? (
                      <>
                        <span className="px-3 py-1.5 rounded-lg text-sm font-medium bg-green-100 text-green-800">
                          ✓ Applied
                        </span>
                        <button
                          onClick={() => handleWithdraw(job.id)}
                          disabled={withdrawingId === job.id}
                          className="px-3 py-1.5 text-sm rounded-lg font-medium text-red-600 hover:bg-red-50 cursor-pointer disabled:opacity-60"
                        >
                          {withdrawingId === job.id ? "Withdrawing..." : "Withdraw"}
                        </button>
                      </>
                    ) : (
                      <button
                        onClick={() => setApplyJob(job)}
                        className="px-4 py-1.5 text-sm rounded-lg font-medium bg-linear-to-r from-sky-500 to-blue-600 text-white hover:from-sky-400 hover:to-blue-500 shadow-lg shadow-sky-500/10 cursor-pointer"
                      >
                        Apply
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {applyJob && (
        <ApplyModal
          job={applyJob}
          onClose={() => setApplyJob(null)}
          onApplied={handleApplied}
        />
      )}
    </div>
  );
};

export default Page;