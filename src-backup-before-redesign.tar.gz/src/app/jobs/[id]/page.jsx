"use client";

import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import React, { useEffect, useState } from "react";
import { formatJobType, getTypeColor } from "@/lib/jobStyles";

function ApplyModal({ job, onClose, onApplied }) {
  const [formData, setFormData] = useState({
    coverLetter: "",
    yearsOfExperience: "",
  });
  const [file, setFile] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [uploadStatus, setUploadStatus] = useState(""); // "" | "uploading" | "applying"
  const [error, setError] = useState("");

  const handleChange = (e) =>
    setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleFileChange = (e) => {
    const selected = e.target.files[0];
    setError("");

    if (!selected) {
      setFile(null);
      return;
    }
    if (selected.type !== "application/pdf") {
      setError("Only PDF files are allowed");
      e.target.value = "";
      setFile(null);
      return;
    }
    if (selected.size > 5 * 1024 * 1024) {
      setError("File too large. Max size is 5MB");
      e.target.value = "";
      setFile(null);
      return;
    }
    setFile(selected);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    if (!file) {
      setError("Please select your CV (PDF)");
      return;
    }

    setSubmitting(true);

    try {
      // Step 1: upload the file to Cloudinary via our own API route
      setUploadStatus("uploading");
      const uploadFormData = new FormData();
      uploadFormData.append("file", file);

      const uploadRes = await fetch("/api/upload", {
        method: "POST",
        // No Content-Type here on purpose — the browser sets the correct
        // multipart boundary automatically for FormData. Setting it manually breaks the upload.
        body: uploadFormData,
      });
      const uploadData = await uploadRes.json();
      if (!uploadRes.ok) throw new Error(uploadData.error || "CV upload failed");

      const cvUrl = uploadData.data.url;

      // Step 2: submit the application with the uploaded file's URL
      setUploadStatus("applying");
      const res = await fetch(`/api/jobs/${job.id}/apply`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ ...formData, cvUrl }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Something went wrong");

      onApplied();
      onClose();
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
      setUploadStatus("");
    }
  };

  return (
    <div
      className="fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-50"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-xl shadow-xl max-w-lg w-full p-6"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between mb-4">
          <h3 className="text-xl font-semibold text-black">Apply to {job.title}</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 text-2xl leading-none cursor-pointer"
          >
            ×
          </button>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-lg px-3 py-2 mb-4">
            ⚠️ {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">CV / Resume (PDF, max 5MB) *</label>
            <input
              type="file"
              accept="application/pdf"
              onChange={handleFileChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-black text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 file:mr-3 file:py-1.5 file:px-3 file:rounded-md file:border-0 file:bg-sky-50 file:text-sky-600 file:cursor-pointer cursor-pointer"
            />
            {file && (
              <p className="text-xs text-gray-500 mt-1">
                Selected: {file.name} ({(file.size / 1024 / 1024).toFixed(2)} MB)
              </p>
            )}
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Years of Experience *</label>
            <input
              type="text"
              name="yearsOfExperience"
              required
              value={formData.yearsOfExperience}
              onChange={handleChange}
              placeholder="e.g. 2"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-black focus:outline-none focus:ring-2 focus:ring-sky-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Cover Letter *</label>
            <textarea
              name="coverLetter"
              required
              rows="5"
              value={formData.coverLetter}
              onChange={handleChange}
              placeholder="Tell them why you're a good fit..."
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-black focus:outline-none focus:ring-2 focus:ring-sky-500"
            />
          </div>
          <div className="flex gap-3 justify-end pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-1.5 text-sm rounded-lg font-medium text-gray-600 hover:bg-gray-100 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-4 py-1.5 text-sm rounded-lg font-medium bg-linear-to-r from-sky-500 to-blue-600 text-white hover:from-sky-400 hover:to-blue-500 cursor-pointer disabled:opacity-60"
            >
              {uploadStatus === "uploading"
                ? "Uploading CV..."
                : uploadStatus === "applying"
                  ? "Submitting..."
                  : "Submit Application"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default function JobDetailPage() {
  const { id } = useParams();
  const router = useRouter();

  const [job, setJob] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [userId, setUserId] = useState(null);
  const [role, setRole] = useState(null);
  const [hasToken, setHasToken] = useState(false);
  const [showApplyModal, setShowApplyModal] = useState(false);
  const [withdrawing, setWithdrawing] = useState(false);

  const fetchJob = async () => {
    setLoading(true);
    setError("");

    try {
      const res = await fetch(`/api/jobs/${id}`);
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Job not found");

      setJob(data.data.data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    setHasToken(!!storedUser);
    if (storedUser) {
      try {
        const parsed = JSON.parse(storedUser);
        setUserId(parsed.id);
        setRole(parsed.role);
      } catch {
        // ignore malformed localStorage
      }
    }

    fetchJob();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const applied =
    userId != null && job?.applications?.some((a) => a.seekerId === userId);
  const isOwner = userId != null && job?.employerId === userId;

  const handleWithdraw = async () => {
    setWithdrawing(true);
    try {
      const res = await fetch(`/api/jobs/${id}/apply`, {
        method: "DELETE",
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Error withdrawing");
      fetchJob();
    } catch (err) {
      alert(err.message);
    } finally {
      setWithdrawing(false);
    }
  };

  if (loading) {
    return (
      <div className="max-w-3xl mx-auto p-4 md:p-6">
        <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-8 h-64 animate-pulse" />
      </div>
    );
  }

  if (error || !job) {
    return (
      <div className="max-w-3xl mx-auto p-4 md:p-6">
        <div className="bg-red-500/10 border border-red-500/30 text-red-400 rounded-lg px-4 py-6 text-center">
          ⚠️ {error || "Job not found"}
        </div>
        <Link href="/" className="text-sky-400 hover:text-sky-300 text-sm font-medium mt-4 inline-block">
          ← Back home
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto p-4 md:p-6">
      <Link href="/" className="text-sky-400 hover:text-sky-300 text-sm font-medium mb-4 inline-block">
        ← Back
      </Link>

      <div className="bg-white border border-gray-200 rounded-xl shadow-sm p-6 md:p-8">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 mb-4">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-black mb-1">{job.title}</h1>
            <p className="text-gray-600">
              {job.company} • {job.location}
            </p>
            {job.employer?.name && (
              <p className="text-gray-400 text-xs mt-1">Posted by {job.employer.name}</p>
            )}
          </div>
          <span
            className={`px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap ${getTypeColor(job.type)}`}
          >
            {formatJobType(job.type)}
          </span>
        </div>

        <p className="text-green-600 font-semibold text-lg mb-6">
          Rs. {job.salary?.toLocaleString()}
        </p>

        <div className="mb-6">
          <h2 className="text-sm font-semibold text-gray-500 uppercase tracking-wide mb-2">
            Description
          </h2>
          <p className="text-gray-800 whitespace-pre-line leading-relaxed">{job.description}</p>
        </div>

        <div className="border-t border-gray-100 pt-6 flex items-center gap-3 flex-wrap">
          {isOwner ? (
            <Link
              href={`/dashboard/edit/${job.id}`}
              className="px-5 py-2.5 rounded-lg font-medium bg-slate-800 text-white hover:bg-slate-700"
            >
              Edit this Job
            </Link>
          ) : role === "EMPLOYER" ? (
            <p className="text-gray-400 text-sm">Employers can&apos;t apply to jobs.</p>
          ) : !hasToken ? (
            <button
              onClick={() => router.push("/auth/login")}
              className="px-5 py-2.5 rounded-lg font-medium bg-linear-to-r from-sky-500 to-blue-600 text-white hover:from-sky-400 hover:to-blue-500"
            >
              Sign in to Apply
            </button>
          ) : applied ? (
            <>
              <span className="px-4 py-2 rounded-lg text-sm font-medium bg-green-100 text-green-800">
                ✓ You&apos;ve applied
              </span>
              <button
                onClick={handleWithdraw}
                disabled={withdrawing}
                className="px-4 py-2 text-sm rounded-lg font-medium text-red-600 hover:bg-red-50 cursor-pointer disabled:opacity-60"
              >
                {withdrawing ? "Withdrawing..." : "Withdraw Application"}
              </button>
            </>
          ) : (
            <button
              onClick={() => setShowApplyModal(true)}
              className="px-5 py-2.5 rounded-lg font-medium bg-linear-to-r from-sky-500 to-blue-600 text-white hover:from-sky-400 hover:to-blue-500 cursor-pointer"
            >
              Apply Now
            </button>
          )}
        </div>
      </div>

      {showApplyModal && (
        <ApplyModal
          job={job}
          onClose={() => setShowApplyModal(false)}
          onApplied={fetchJob}
        />
      )}
    </div>
  );
}