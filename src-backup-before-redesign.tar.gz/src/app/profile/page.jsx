"use client";

import React, { useEffect, useState } from "react";

export default function ProfilePage() {
  const [skills, setSkills] = useState([]);
  const [newSkill, setNewSkill] = useState("");
  const [loading, setLoading] = useState(true);
  const [adding, setAdding] = useState(false);
  const [error, setError] = useState("");

  const fetchSkills = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/skills");
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Error fetching skills");
      setSkills(data.data || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSkills();
  }, []);

  const handleAdd = async (e) => {
    e.preventDefault();
    if (!newSkill.trim()) return;

    setAdding(true);
    setError("");

    try {
      const res = await fetch("/api/skills", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ name: newSkill }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Error adding skill");

      setSkills((prev) => [...prev, data.data]);
      setNewSkill("");
    } catch (err) {
      setError(err.message);
    } finally {
      setAdding(false);
    }
  };

  const handleRemove = async (id) => {
    try {
      const res = await fetch("/api/skills", {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ id }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Error removing skill");

      setSkills((prev) => prev.filter((s) => s.id !== id));
    } catch (err) {
      alert(err.message);
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-4 md:p-6">
      <h1 className="text-4xl font-bold text-white mb-2">My Skills</h1>
      <p className="text-gray-400 mb-6">
        Add skills to your profile so employers get a fuller picture of you.
      </p>

      {error && (
        <div className="bg-red-500/10 border border-red-500/30 text-red-400 rounded-lg px-4 py-3 mb-6">
          ⚠️ {error}
        </div>
      )}

      <form onSubmit={handleAdd} className="flex gap-3 mb-6">
        <input
          type="text"
          value={newSkill}
          onChange={(e) => setNewSkill(e.target.value)}
          placeholder="e.g. React, Figma, SQL..."
          className="flex-1 px-4 py-2.5 rounded-lg bg-slate-800 border border-slate-700 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-sky-500"
        />
        <button
          type="submit"
          disabled={adding}
          className="px-5 py-2.5 rounded-lg font-medium bg-linear-to-r from-sky-500 to-blue-600 text-white hover:from-sky-400 hover:to-blue-500 shadow-lg shadow-sky-500/10 cursor-pointer disabled:opacity-60"
        >
          {adding ? "Adding..." : "Add Skill"}
        </button>
      </form>

      {loading ? (
        <div className="flex gap-2 flex-wrap">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-9 w-24 bg-slate-800/50 rounded-full animate-pulse" />
          ))}
        </div>
      ) : skills.length === 0 ? (
        <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-8 text-center text-gray-400">
          No skills added yet. Add your first one above!
        </div>
      ) : (
        <div className="flex gap-2 flex-wrap">
          {skills.map((skill) => (
            <span
              key={skill.id}
              className="flex items-center gap-2 bg-sky-500/15 text-sky-300 px-4 py-2 rounded-full text-sm font-medium"
            >
              {skill.name}
              <button
                onClick={() => handleRemove(skill.id)}
                className="text-sky-400 hover:text-red-400 cursor-pointer"
                aria-label={`Remove ${skill.name}`}
              >
                ×
              </button>
            </span>
          ))}
        </div>
      )}
    </div>
  );
}