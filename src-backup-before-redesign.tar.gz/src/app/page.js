"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { formatJobType, getTypeColor } from "@/lib/jobStyles";

export default function HomePage() {
  const [featuredJobs, setFeaturedJobs] = useState([]);
  const [stats, setStats] = useState({ totalJobs: 0, totalCompanies: 0 });
  const [loading, setLoading] = useState(true);
  const [role, setRole] = useState(null);
  const [hasToken, setHasToken] = useState(false);

  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    setHasToken(!!storedUser);
    if (storedUser) {
      try {
        setRole(JSON.parse(storedUser).role);
      } catch {
        setRole(null);
      }
    }

    fetch("/api/jobs/public")
      .then((res) => res.json())
      .then((json) => {
        if (json.success) {
          setFeaturedJobs(json.data.featuredJobs || []);
          setStats(json.data.stats || { totalJobs: 0, totalCompanies: 0 });
        }
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="animate-fade-in">
      <section className="max-w-6xl mx-auto px-4 sm:px-6 py-16 md:py-24 text-center">
        <div className="text-5xl mb-6">💼</div>
        <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold text-white mb-4">
          Find your next role on{" "}
          <span className="bg-gradient-to-r from-sky-400 to-blue-500 bg-clip-text text-transparent">
            CareerHub
          </span>
        </h1>
        <p className="text-lg text-slate-400 max-w-2xl mx-auto mb-8 leading-relaxed">
          Browse open positions, apply in minutes, and manage applications — or
          post jobs and hire talent from one place.
        </p>

        {!loading && (
          <div className="flex items-center justify-center gap-6 mb-10 text-sm">
            <div className="px-4 py-2 rounded-lg bg-slate-800/60 border border-slate-700">
              <span className="text-sky-400 font-semibold text-lg">{stats.totalJobs}</span>
              <span className="text-slate-400 ml-2">open jobs</span>
            </div>
            <div className="px-4 py-2 rounded-lg bg-slate-800/60 border border-slate-700">
              <span className="text-sky-400 font-semibold text-lg">{stats.totalCompanies}</span>
              <span className="text-slate-400 ml-2">companies</span>
            </div>
          </div>
        )}

        <div className="flex flex-wrap items-center justify-center gap-3">
          {!hasToken && (
            <>
              <Link href="/auth/register" className="px-8 py-3 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 text-white font-semibold hover:from-sky-400 hover:to-blue-500 transition-all shadow-lg shadow-sky-500/20">
                Get Started
              </Link>
              <Link href="/auth/login" className="px-8 py-3 rounded-xl border border-slate-600 text-slate-300 font-semibold hover:border-sky-500 hover:text-sky-400 transition-all">
                Sign In
              </Link>
            </>
          )}
          {hasToken && role === "SEEKER" && (
            <>
              <Link href="/jobs" className="px-8 py-3 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 text-white font-semibold hover:from-sky-400 hover:to-blue-500 transition-all shadow-lg shadow-sky-500/20">
                Browse Jobs
              </Link>
              <Link href="/applications" className="px-8 py-3 rounded-xl border border-slate-600 text-slate-300 font-semibold hover:border-sky-500 hover:text-sky-400 transition-all">
                My Applications
              </Link>
            </>
          )}
          {hasToken && role === "EMPLOYER" && (
            <>
              <Link href="/dashboard" className="px-8 py-3 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 text-white font-semibold hover:from-sky-400 hover:to-blue-500 transition-all shadow-lg shadow-sky-500/20">
                Go to Dashboard
              </Link>
              <Link href="/dashboard/new" className="px-8 py-3 rounded-xl border border-slate-600 text-slate-300 font-semibold hover:border-sky-500 hover:text-sky-400 transition-all">
                Post a Job
              </Link>
            </>
          )}
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-4 sm:px-6 pb-20">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-white">Latest Opportunities</h2>
          {hasToken && role === "SEEKER" && (
            <Link href="/jobs" className="text-sm text-sky-400 hover:text-sky-300 font-medium">
              View all →
            </Link>
          )}
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-slate-800/50 border border-slate-700 rounded-xl p-6 h-40 animate-pulse" />
            ))}
          </div>
        ) : featuredJobs.length === 0 ? (
          <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-12 text-center text-slate-400">
            <p className="text-lg mb-2">No jobs posted yet.</p>
            {!hasToken && (
              <Link href="/auth/register" className="text-sky-400 hover:text-sky-300 text-sm font-medium">
                Be the first to join →
              </Link>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {featuredJobs.map((job) => (
              <Link key={job.id} href={`/jobs/${job.id}`} className="bg-white border border-gray-200 rounded-xl p-5 hover:shadow-md hover:-translate-y-0.5 transition-all group">
                <div className="flex items-start justify-between gap-2 mb-3">
                  <h3 className="font-semibold text-black group-hover:text-sky-600 transition-colors line-clamp-1">{job.title}</h3>
                  <span className={`px-2 py-0.5 rounded-full text-xs font-medium whitespace-nowrap ${getTypeColor(job.type)}`}>
                    {formatJobType(job.type)}
                  </span>
                </div>
                <p className="text-gray-600 text-sm mb-3">{job.company} • {job.location}</p>
                <div className="flex items-center justify-between">
                  <span className="text-green-600 font-medium text-sm">Rs. {job.salary?.toLocaleString()}</span>
                  <span className="text-xs text-gray-400">{new Date(job.createdAt).toLocaleDateString()}</span>
                </div>
              </Link>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}