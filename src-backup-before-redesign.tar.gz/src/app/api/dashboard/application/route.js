import { errorResponse, successResponse } from "@/lib/api";
import { getAuthUser } from "@/lib/auth";
import { prisma } from "@/lib/db";

const VALID_STATUSES = ["PENDING", "APPROVED", "DECLINED"];

export async function PATCH(request) {
  const user = getAuthUser(request);
  if (!user) return errorResponse("UNAUTHORIZED", 401);
  if (user.role !== "EMPLOYER") return errorResponse("FORBIDDEN", 403);

  try {
    const body = await request.json();
    const { appId, status } = body;

    const applicationId = parseInt(appId);
    if (isNaN(applicationId)) return errorResponse("Invalid application ID", 400);
    if (!VALID_STATUSES.includes(status))
      return errorResponse("Status must be PENDING, APPROVED or DECLINED", 400);

    // Employers can only change applications to their own jobs
    const application = await prisma.application.findUnique({
      where: { id: applicationId },
      select: { job: { select: { employerId: true } } },
    });

    if (!application) return errorResponse("Application not found", 404);
    if (application.job.employerId !== user.id)
      return errorResponse(
        "FORBIDDEN: Can only update applications to your own jobs",
        403,
      );

    const changedStatus = await prisma.application.update({
      where: {
        id: applicationId,
      },
      data: { status },
    });

    return successResponse(
      {
        message: "Application status changed successfully!",
        data: changedStatus,
      },
      200,
    );
  } catch (err) {
    console.error("[Application Status Error]:", err);
    return errorResponse("Error in the application status change process");
  }
}
