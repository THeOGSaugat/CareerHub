import { errorResponse, successResponse } from "@/lib/api";
import { getAuthUser } from "@/lib/auth";
import { prisma } from "@/lib/db";

const JOB_TYPES = ["FULL_TIME", "PART_TIME", "CONTRACT", "INTERNSHIP"];

export async function POST(request) {
  const user = getAuthUser(request);
  // verify logged in users
  if (!user) return errorResponse("UNAUTHORIZED!", 401);
  // verify role
  if (user.role !== "EMPLOYER")
    return errorResponse("FORBIDDEN: Employers Only!", 403);
  // yo kaam, verify paxi hunu paro
  const body = await request.json();
  const { title, description, location, salary, company, type } = body;
  // verify values
  if (!title?.trim() || !description?.trim() || !location?.trim() || !company?.trim())
    return errorResponse("Important inputs not filled yet!", 400);

  const salaryValue = parseInt(salary);
  if (isNaN(salaryValue) || salaryValue < 0)
    return errorResponse("Salary must be a valid number", 400);

  if (type && !JOB_TYPES.includes(type))
    return errorResponse("Invalid job type", 400);
  try {
    // insert values to database -> PostgreSQL
    const newJob = await prisma.job.create({
      data: {
        title,
        description,
        location,
        salary: salaryValue,
        company,
        type,
        employerId: user.id,
      },
    });
    return successResponse(newJob, 201);
  } catch (err) {
    console.error("[API Error]:", err);
    return errorResponse("Error inserting jobs to the database");
  }
}
export async function GET(request) {
  const user = getAuthUser(request);
  if (!user) return errorResponse("UNAUTHORIZED", 401);
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get("search") || "";
    const type = searchParams.get("type") || "";
    const sort = searchParams.get("sort") || "newest";

    const where = {
      ...(search
        ? {
            OR: [
              { title: { contains: search, mode: "insensitive" } },
              { location: { contains: search, mode: "insensitive" } },
              { company: { contains: search, mode: "insensitive" } },
            ],
          }
        : {}),
      ...(type ? { type } : {}),
    };

    const orderBy =
      sort === "oldest"
        ? { createdAt: "asc" }
        : sort === "salary_high"
          ? { salary: "desc" }
          : sort === "salary_low"
            ? { salary: "asc" }
            : { createdAt: "desc" }; // "newest" default

    const jobs = await prisma.job.findMany({
      where,
      include: {
        employer: {
          select: {
            name: true,
            email: true,
          },
        },
        applications: {
          select: {
            seekerId: true,
          },
        },
      },
      orderBy,
    });
    return successResponse(jobs, 200);
  } catch (err) {
    console.error("[API Error]:", err);
    return errorResponse("Error trying to fetch jobs");
  }
}