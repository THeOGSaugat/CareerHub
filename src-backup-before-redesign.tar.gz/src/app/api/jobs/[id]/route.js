import { errorResponse, successResponse } from "@/lib/api";
import { getAuthUser } from "@/lib/auth";
import { prisma } from "@/lib/db";

const JOB_TYPES = ["FULL_TIME", "PART_TIME", "CONTRACT", "INTERNSHIP"];

export async function GET(request, { params }) {
  const { id } = await params;
  const jobId = parseInt(id);
  if (isNaN(jobId)) return errorResponse("Invalid Params ID", 400);

  const user = getAuthUser(request);

  try {
    const job = await prisma.job.findUnique({
      where: {
        id: jobId,
      },
      include: {
        employer: {
          select: { name: true, email: true },
        },
        applications: {
          select: { seekerId: true },
        },
      },
    });

    if (!job) return errorResponse("Job not found", 404);

    return successResponse(
      { message: "Data retrieved successfully!", data: job },
      200,
    );
  } catch (err) {
    console.error("[API Error]:", err);
    return errorResponse("Error getting the particular Job");
  }
}

export async function PUT(request, { params }) {
  const { id } = await params;
  const jobId = parseInt(id);
  if (isNaN(jobId)) return errorResponse("Invalid Params ID", 400);

  const user = getAuthUser(request);

  if (!user) return errorResponse("UNAUTHORIZED!", 401);
  if (user.role !== "EMPLOYER") return errorResponse("FORBIDDEN!", 403);

  const body = await request.json();
  const { title, description, location, salary, company, type } = body;

  if (!title?.trim() || !description?.trim() || !location?.trim() || !company?.trim())
    return errorResponse("Important inputs not filled yet!", 400);

  const salaryValue = parseInt(salary);
  if (isNaN(salaryValue) || salaryValue < 0)
    return errorResponse("Salary must be a valid number", 400);

  if (!JOB_TYPES.includes(type)) return errorResponse("Invalid job type", 400);

  try {
    const existingJob = await prisma.job.findUnique({
      where: {
        id: jobId,
      },
      select: { employerId: true },
    });

    if (!existingJob) return errorResponse("Job does not exist!", 404);
    if (existingJob.employerId !== user.id)
      return errorResponse(
        "FORBIDDEN: Can only update your particular job",
        403,
      );

    const job = await prisma.job.update({
      where: {
        id: jobId,
      },
      // never pass the raw body: it could overwrite employerId or id
      data: { title, description, location, salary: salaryValue, company, type },
    });

    return successResponse(
      { message: "Job updated successfully!", data: job },
      200,
    );
  } catch (err) {
    console.error("[API Error]:", err);
    return errorResponse("Error updating the particular Job");
  }
}

export async function DELETE(request, { params }) {
  const { id } = await params;
  const jobId = parseInt(id);
  if (isNaN(jobId)) return errorResponse("Invalid Job ID", 400);

  const user = getAuthUser(request);
  if (!user) return errorResponse("UNAUTHORIZED", 401);
  if (user.role !== "EMPLOYER") return errorResponse("FORBIDDEN", 403);

  try {
    const existingJob = await prisma.job.findUnique({
      where: {
        id: jobId,
      },
      select: { employerId: true },
    });

    if (!existingJob) return errorResponse("Job does not exist!", 404);
    if (existingJob.employerId !== user.id)
      return errorResponse(
        "FORBIDDEN: Can only update your particular job",
        403,
      );

    const deleteJob = await prisma.job.delete({
      where: {
        id: jobId,
      },
    });

    return successResponse({ message: "Job deleted successfully", data: deleteJob }, 200);
  } catch (err) {
    console.error("[API Error]:", err);
    return errorResponse("Error deleting the job");
  }
}