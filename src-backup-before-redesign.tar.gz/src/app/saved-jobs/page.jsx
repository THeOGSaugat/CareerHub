"use client";

import Link from "next/link";
import React, { useEffect, useState } from "react";

const TYPE_STYLES = {
  FULL_TIME: "bg-blue-100 text-blue-800",
  PART_TIME: "bg-amber-100 text-amber-800",
  CONTRACT: "bg-orange-100 text-orange-800",
  INTERNSHIP: "bg-purple-100 text-purple-800",
};

function getTypeColor(type) {
  return TYPE_STYLES[type] || "bg-gray-100 text-gray-800";
}

export default function SavedJobsPage() {
  const [savedJobs, setSavedJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [removingId, setRemovingId] = useState(null);

  const fetchSavedJobs = async () => {
    setLoading(true);
    setError("");

    try {
      const res = await fetch("/api/saved-jobs");
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Error fetching saved jobs");
      setSavedJobs(data.data || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSavedJobs();
  }, []);

  const handleRemove = async (jobId) => {
    setRemovingId(jobId);

    try {
      const res = await fetch("/api/saved-jobs", {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ jobId }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Error removing saved job");

      setSavedJobs((prev) => prev.filter((s) => s.jobId !== jobId));
    } catch (err) {
      alert(err.message);
    } finally {
      setRemovingId(null);
    }
  };

  return (
    <div className="max-w-5xl mx-auto p-4 md:p-6">
      <div className="flex items-center justify-between flex-wrap gap-4 mb-6">
        <h1 className="text-4xl font-bold text-white">Saved Jobs</h1>
        <Link
          href="/jobs"
          className="px-4 py-1.5 text-sm rounded-lg font-medium bg-linear-to-r from-sky-500 to-blue-600 text-white hover:from-sky-400 hover:to-blue-500 shadow-lg shadow-sky-500/10"
        >
          Browse Jobs
        </Link>
      </div>

      {error && (
        <div className="bg-red-500/10 border border-red-500/30 text-red-400 rounded-lg px-4 py-3 mb-6">
          ⚠️ {error}
        </div>
      )}

      {loading ? (
        <div className="flex flex-col gap-4">
          {[1, 2].map((i) => (
            <div key={i} className="bg-slate-800/50 border border-slate-700 rounded-xl p-6 h-28 animate-pulse" />
          ))}
        </div>
      ) : savedJobs.length === 0 ? (
        <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-12 text-center text-gray-400">
          <p className="text-lg mb-4">No saved jobs yet — bookmark a few while browsing!</p>
          <Link
            href="/jobs"
            className="inline-block px-4 py-1.5 text-sm rounded-lg font-medium bg-linear-to-r from-sky-500 to-blue-600 text-white hover:from-sky-400 hover:to-blue-500"
          >
            Browse open jobs
          </Link>
        </div>
      ) : (
        <div className="flex flex-col gap-4">
          {savedJobs.map(({ job, jobId }) => (
            <div
              key={jobId}
              className="bg-white border border-gray-200 rounded-xl shadow-sm hover:shadow-md transition-all p-6"
            >
              <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 mb-3">
                <div>
                  <h2 className="text-xl font-semibold text-black mb-1">{job.title}</h2>
                  <p className="text-gray-600">
                    {job.company} • {job.location}
                  </p>
                </div>
                <span
                  className={`px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap ${getTypeColor(job.type)}`}
                >
                  {job.type.replace("_", " ")}
                </span>
              </div>

              <p className="text-gray-700 text-sm mb-4 line-clamp-2">{job.description}</p>

              <div className="flex items-center justify-between flex-wrap gap-3">
                <span className="font-medium text-green-600">
                  Rs. {job.salary?.toLocaleString()}
                </span>
                <div className="flex items-center gap-3">
                  <Link
                    href={`/jobs/${jobId}`}
                    className="px-3 py-1.5 text-sm rounded-lg font-medium text-sky-600 hover:bg-sky-50"
                  >
                    View Details
                  </Link>
                  <button
                    onClick={() => handleRemove(jobId)}
                    disabled={removingId === jobId}
                    className="px-3 py-1.5 text-sm rounded-lg font-medium text-red-600 hover:bg-red-50 cursor-pointer disabled:opacity-60"
                  >
                    {removingId === jobId ? "Removing..." : "Remove"}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}