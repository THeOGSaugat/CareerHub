"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { logoutHandler } from "@/app/actions/auth";

const SEEKER_LINKS = [
  { href: "/jobs", label: "Browse Jobs" },
  { href: "/applications", label: "My Applications" },
  { href: "/saved-jobs", label: "Saved Jobs" },
  { href: "/profile", label: "My Skills" },
];

const EMPLOYER_LINKS = [
  { href: "/dashboard", label: "Dashboard" },
  { href: "/dashboard/new", label: "Post Job" },
];

// `user` comes from the root layout, which reads it from the auth cookie
export default function Navbar({ user }) {
  const pathname = usePathname();
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [loggingOut, setLoggingOut] = useState(false);
  const router = useRouter();

  const isLoggedIn = !!user;
  const links =
    user?.role === "SEEKER"
      ? SEEKER_LINKS
      : user?.role === "EMPLOYER"
        ? EMPLOYER_LINKS
        : [];

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 10);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Session expired or logged out elsewhere: drop the stale display info
  useEffect(() => {
    if (!user) {
      localStorage.removeItem("user");
      localStorage.removeItem("token");
    }
  }, [user]);

  const handleLogout = async () => {
    setLoggingOut(true);
    try {
      const result = await logoutHandler();
      localStorage.removeItem("user");
      localStorage.removeItem("token");
      router.push(result.redirectTo);
      router.refresh();
    } catch {
      alert("Error logging out");
    } finally {
      setLoggingOut(false);
    }
  };

  const isActive = (path) => pathname === path;

  const navLinkClass = (path) =>
    `px-3 py-1.5 text-sm rounded-lg font-medium transition-all ${
      isActive(path)
        ? "bg-sky-500/15 text-sky-400"
        : "text-slate-300 hover:text-sky-400"
    }`;

  const authButtonClass = (path) =>
    `px-4 py-1.5 text-sm rounded-lg font-medium transition-all ${
      isActive(path)
        ? "bg-sky-500/15 text-sky-400"
        : "bg-linear-to-r from-sky-500 to-blue-600 text-white hover:from-sky-400 hover:to-blue-500 shadow-lg shadow-sky-500/10"
    }`;

  return (
    <nav
      className={`sticky top-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-slate-900/80 backdrop-blur-xl border-b border-slate-800/80 shadow-lg shadow-black/10"
          : "bg-slate-900 border-b border-slate-800"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 group">
            <span className="text-2xl group-hover:scale-110 transition-transform duration-300">
              💼
            </span>
            <span className="text-xl font-bold bg-linear-to-r from-sky-400 to-blue-500 bg-clip-text text-transparent group-hover:from-sky-300 group-hover:to-blue-400 transition-all">
              CareerHub
            </span>
          </Link>

          {/* Role-based nav links */}
          {links.length > 0 && (
            <div className="hidden md:flex items-center gap-1">
              {links.map((link) => (
                <Link key={link.href} href={link.href} className={navLinkClass(link.href)}>
                  {link.label}
                </Link>
              ))}
            </div>
          )}

          {/* Register / Login / Logout */}
          <div className="flex items-center gap-2">
            {isLoggedIn ? (
              <button
                onClick={handleLogout}
                disabled={loggingOut}
                className={`${authButtonClass("")} cursor-pointer disabled:opacity-60`}
              >
                {loggingOut ? "Logging out..." : "Log Out"}
              </button>
            ) : (
              <>
                <Link href="/auth/register" className={authButtonClass("/auth/register")}>
                  Register
                </Link>
                <Link href="/auth/login" className={authButtonClass("/auth/login")}>
                  Log In
                </Link>
              </>
            )}

            {/* Mobile menu toggle */}
            {links.length > 0 && (
              <button
                onClick={() => setMenuOpen((open) => !open)}
                aria-label={menuOpen ? "Close menu" : "Open menu"}
                aria-expanded={menuOpen}
                className="md:hidden p-2 rounded-lg text-slate-300 hover:text-sky-400 hover:bg-slate-800 cursor-pointer"
              >
                <svg
                  className="w-6 h-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                  strokeWidth={2}
                  strokeLinecap="round"
                >
                  {menuOpen ? (
                    <path d="M6 6l12 12M18 6L6 18" />
                  ) : (
                    <path d="M4 7h16M4 12h16M4 17h16" />
                  )}
                </svg>
              </button>
            )}
          </div>
        </div>

        {/* Mobile nav links */}
        {menuOpen && links.length > 0 && (
          <div className="md:hidden flex flex-col gap-1 pb-4 animate-fade-in">
            {links.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setMenuOpen(false)}
                className={`${navLinkClass(link.href)} py-2.5`}
              >
                {link.label}
              </Link>
            ))}
          </div>
        )}
      </div>
    </nav>
  );
}
