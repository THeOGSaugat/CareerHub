// src/app/page.js
// ─── Landing Page ─────────────────────────────────────────────
// Rendered on the server so visitors and search engines get real content.

import Link from "next/link";
import {
  ArrowRight,
  Building2,
  ClipboardCheck,
  Search,
  Send,
  UserRoundPen,
} from "lucide-react";
import JobCard from "@/components/jobs/JobCard";
import { ButtonLink, buttonClass } from "@/components/ui/Button";
import Card from "@/components/ui/Card";
import CompanyAvatar from "@/components/ui/CompanyAvatar";
import EmptyState from "@/components/ui/EmptyState";
import { inputClass } from "@/components/ui/Field";
import { prisma } from "@/lib/db";
import { getViewerContext, jobCardSelect, openJobsWhere } from "@/lib/jobs";
import { getSessionUser } from "@/lib/session";

const STEPS = [
  {
    icon: UserRoundPen,
    title: "Build your profile",
    text: "Add your skills, experience and CV once. We reuse them every time you apply.",
  },
  {
    icon: Search,
    title: "Find jobs that fit",
    text: "Filter by type, work mode and level, and see how well your skills match each role.",
  },
  {
    icon: Send,
    title: "Apply and track",
    text: "Apply in a minute, then follow every application from review to offer.",
  },
];

export default async function HomePage() {
  const user = await getSessionUser();
  const where = openJobsWhere();

  const [viewer, featuredJobs, totalJobs, companies, categories] =
    await Promise.all([
      getViewerContext(user),
      prisma.job.findMany({
        where,
        select: jobCardSelect,
        orderBy: { createdAt: "desc" },
        take: 6,
      }),
      prisma.job.count({ where }),
      prisma.job.groupBy({
        by: ["company"],
        where,
        _count: { company: true },
        orderBy: { _count: { company: "desc" } },
      }),
      prisma.job.groupBy({
        by: ["category"],
        where,
        _count: { category: true },
        orderBy: { _count: { category: "desc" } },
        take: 8,
      }),
    ]);

  const topCompanies = companies.slice(0, 6);

  return (
    <div className="animate-fade-in">
      {/* ── Hero ─────────────────────────────────────────────── */}
      <section className="hero-glow border-b border-slate-800/60">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 pt-16 pb-14 md:pt-24 md:pb-20 text-center">
          <p className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-sky-500/20 bg-sky-500/10 text-sky-300 text-xs font-medium mb-6">
            <span className="w-1.5 h-1.5 rounded-full bg-sky-400" />
            {totalJobs} open {totalJobs === 1 ? "role" : "roles"} at{" "}
            {companies.length} {companies.length === 1 ? "company" : "companies"}
          </p>

          <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold text-white tracking-tight mb-5">
            Find the job that{" "}
            <span className="bg-linear-to-r from-sky-400 to-blue-500 bg-clip-text text-transparent">
              fits your skills
            </span>
          </h1>
          <p className="text-lg text-slate-400 max-w-2xl mx-auto mb-9 leading-relaxed">
            Browse open positions, see how well you match, and apply in
            minutes — or post a job and hire from one place.
          </p>

          {/* Plain GET form: works without JavaScript */}
          <form
            action="/jobs"
            role="search"
            className="flex flex-col sm:flex-row gap-2 max-w-2xl mx-auto p-2 rounded-2xl bg-slate-900/80 border border-slate-700 shadow-2xl shadow-black/30"
          >
            <div className="relative flex-1">
              <Search
                className="w-5 h-5 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
                aria-hidden="true"
              />
              <input
                type="search"
                name="search"
                aria-label="Search jobs"
                placeholder="Job title, company or location"
                className={`${inputClass} pl-11 py-3 border-transparent bg-transparent`}
              />
            </div>
            <button type="submit" className={buttonClass({ size: "lg" })}>
              Search jobs
            </button>
          </form>

          <div className="flex flex-wrap items-center justify-center gap-3 mt-8">
            {!user && (
              <>
                <ButtonLink href="/auth/register" variant="secondary">
                  Create a free account
                </ButtonLink>
                <ButtonLink href="/auth/login" variant="ghost">
                  Log in
                </ButtonLink>
              </>
            )}
            {user?.role === "SEEKER" && (
              <>
                <ButtonLink href="/applications" variant="secondary">
                  My applications
                </ButtonLink>
                <ButtonLink href="/profile" variant="ghost">
                  Update my profile
                </ButtonLink>
              </>
            )}
            {user?.role === "EMPLOYER" && (
              <>
                <ButtonLink href="/dashboard" variant="secondary">
                  Go to dashboard
                </ButtonLink>
                <ButtonLink href="/dashboard/new" variant="ghost">
                  Post a job
                </ButtonLink>
              </>
            )}
          </div>
        </div>
      </section>

      {/* ── Categories ───────────────────────────────────────── */}
      {categories.length > 1 && (
        <section className="max-w-6xl mx-auto px-4 sm:px-6 pt-14">
          <h2 className="text-2xl font-bold text-white mb-6">
            Browse by category
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {categories.map(({ category, _count }) => (
              <Link
                key={category}
                href={`/jobs?category=${encodeURIComponent(category)}`}
                className="group flex items-center justify-between gap-3 px-4 py-3.5 rounded-xl bg-slate-900/70 border border-slate-800 hover:border-sky-500/40 hover:bg-slate-900 transition-colors"
              >
                <span className="font-medium text-slate-200 group-hover:text-white">
                  {category}
                </span>
                <span className="text-xs text-slate-500">
                  {_count.category} {_count.category === 1 ? "job" : "jobs"}
                </span>
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* ── Latest jobs ──────────────────────────────────────── */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 pt-14">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-white">Latest opportunities</h2>
          <Link
            href="/jobs"
            className="inline-flex items-center gap-1 text-sm text-sky-400 hover:text-sky-300 font-medium"
          >
            View all jobs
            <ArrowRight className="w-4 h-4" aria-hidden="true" />
          </Link>
        </div>

        {featuredJobs.length === 0 ? (
          <EmptyState
            icon={ClipboardCheck}
            title="No jobs posted yet"
            description="New roles will show up here as soon as employers post them."
          >
            {!user && (
              <ButtonLink href="/auth/register">Be the first to join</ButtonLink>
            )}
          </EmptyState>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {featuredJobs.map((job) => (
              <JobCard key={job.id} job={job} viewer={viewer} compact />
            ))}
          </div>
        )}
      </section>

      {/* ── Top companies ────────────────────────────────────── */}
      {topCompanies.length > 1 && (
        <section className="max-w-6xl mx-auto px-4 sm:px-6 pt-14">
          <h2 className="text-2xl font-bold text-white mb-6">
            Companies hiring now
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {topCompanies.map(({ company, _count }) => (
              <Link
                key={company}
                href={`/jobs?search=${encodeURIComponent(company)}`}
                className="flex items-center gap-3 px-4 py-3.5 rounded-xl bg-slate-900/70 border border-slate-800 hover:border-slate-600 transition-colors"
              >
                <CompanyAvatar name={company} />
                <span className="min-w-0">
                  <span className="block font-medium text-slate-200 truncate">
                    {company}
                  </span>
                  <span className="block text-xs text-slate-500">
                    {_count.company} open{" "}
                    {_count.company === 1 ? "role" : "roles"}
                  </span>
                </span>
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* ── How it works ─────────────────────────────────────── */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 pt-14">
        <h2 className="text-2xl font-bold text-white mb-6">How it works</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {STEPS.map(({ icon: Icon, title, text }, index) => (
            <Card key={title} className="p-6">
              <div className="flex items-center gap-3 mb-3">
                <span className="flex items-center justify-center w-10 h-10 rounded-xl bg-sky-500/10 border border-sky-500/20 text-sky-400">
                  <Icon className="w-5 h-5" aria-hidden="true" />
                </span>
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                  Step {index + 1}
                </span>
              </div>
              <h3 className="font-semibold text-white mb-1.5">{title}</h3>
              <p className="text-sm text-slate-400 leading-relaxed">{text}</p>
            </Card>
          ))}
        </div>
      </section>

      {/* ── Employer call to action ──────────────────────────── */}
      {user?.role !== "SEEKER" && (
        <section className="max-w-6xl mx-auto px-4 sm:px-6 pt-14">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 p-8 rounded-2xl border border-sky-500/20 bg-linear-to-r from-sky-500/10 to-blue-600/10">
            <div className="flex items-start gap-4">
              <span className="hidden sm:flex items-center justify-center w-12 h-12 shrink-0 rounded-xl bg-sky-500/15 text-sky-400">
                <Building2 className="w-6 h-6" aria-hidden="true" />
              </span>
              <div>
                <h2 className="text-2xl font-bold text-white mb-1.5">
                  Hiring? Reach candidates today
                </h2>
                <p className="text-slate-300 max-w-xl">
                  Post a job in minutes, see how each applicant matches the
                  skills you need, and move them from review to offer in one
                  dashboard.
                </p>
              </div>
            </div>
            <ButtonLink
              href={user?.role === "EMPLOYER" ? "/dashboard/new" : "/auth/register"}
              size="lg"
              className="shrink-0"
            >
              Post a job
            </ButtonLink>
          </div>
        </section>
      )}
    </div>
  );
}
