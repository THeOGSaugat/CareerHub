// src/components/ui/Card.jsx
// ─── Surface Card ─────────────────────────────────────────────

export const cardClass =
  "bg-slate-900/70 border border-slate-800 rounded-2xl";

export default function Card({ className = "", as: Tag = "div", ...props }) {
  return <Tag className={`${cardClass} ${className}`} {...props} />;
}
