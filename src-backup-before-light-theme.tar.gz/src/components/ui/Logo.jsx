// src/components/ui/Logo.jsx
// ─── Brand Mark ───────────────────────────────────────────────

import Link from "next/link";
import { BriefcaseBusiness } from "lucide-react";

export default function Logo({ className = "" }) {
  return (
    <Link href="/" className={`flex items-center gap-2.5 group ${className}`}>
      <span className="flex items-center justify-center w-9 h-9 rounded-xl bg-linear-to-br from-sky-400 to-blue-600 text-white shadow-lg shadow-sky-500/20 group-hover:scale-105 transition-transform">
        <BriefcaseBusiness className="w-5 h-5" aria-hidden="true" />
      </span>
      <span className="text-xl font-bold text-white tracking-tight">
        Career<span className="text-sky-400">Hub</span>
      </span>
    </Link>
  );
}
