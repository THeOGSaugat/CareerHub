// src/components/ui/Field.jsx
// ─── Form Controls ────────────────────────────────────────────
// Label + control + optional hint, with one shared input style.

export const inputClass =
  "w-full px-3.5 py-2.5 rounded-lg bg-slate-950/60 border border-slate-700 text-slate-100 placeholder-slate-500 focus:border-sky-500 transition-colors disabled:opacity-60";

export function Field({ label, htmlFor, hint, required, className = "", children }) {
  return (
    <div className={className}>
      {label && (
        <label
          htmlFor={htmlFor}
          className="block text-sm font-medium text-slate-300 mb-1.5"
        >
          {label}
          {required && <span className="text-sky-400"> *</span>}
        </label>
      )}
      {children}
      {hint && <p className="text-xs text-slate-500 mt-1.5">{hint}</p>}
    </div>
  );
}

export function Input({ className = "", ...props }) {
  return <input className={`${inputClass} ${className}`} {...props} />;
}

export function Textarea({ className = "", ...props }) {
  return <textarea className={`${inputClass} ${className}`} {...props} />;
}

export function Select({ className = "", ...props }) {
  return <select className={`${inputClass} ${className}`} {...props} />;
}
