// src/components/ui/Button.jsx
// ─── Button & ButtonLink ──────────────────────────────────────
// One set of button styles for the whole app.

import Link from "next/link";

const BASE =
  "inline-flex items-center justify-center gap-2 font-medium whitespace-nowrap transition-all cursor-pointer disabled:opacity-60 disabled:cursor-not-allowed focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400/60";

const VARIANTS = {
  primary:
    "bg-linear-to-r from-sky-500 to-blue-600 text-white hover:from-sky-400 hover:to-blue-500 shadow-lg shadow-sky-500/15",
  secondary:
    "border border-slate-700 bg-slate-800/60 text-slate-200 hover:border-slate-500 hover:bg-slate-800",
  ghost: "text-slate-300 hover:text-white hover:bg-slate-800",
  danger: "text-red-400 hover:text-red-300 hover:bg-red-500/10",
};

const SIZES = {
  sm: "px-3 py-1.5 text-sm rounded-lg",
  md: "px-4 py-2 text-sm rounded-lg",
  lg: "px-6 py-3 text-base rounded-xl",
};

export function buttonClass({ variant = "primary", size = "md", className = "" } = {}) {
  return `${BASE} ${VARIANTS[variant]} ${SIZES[size]} ${className}`;
}

export default function Button({
  variant,
  size,
  className,
  type = "button",
  ...props
}) {
  return (
    <button
      type={type}
      className={buttonClass({ variant, size, className })}
      {...props}
    />
  );
}

export function ButtonLink({ variant, size, className, ...props }) {
  return <Link className={buttonClass({ variant, size, className })} {...props} />;
}
