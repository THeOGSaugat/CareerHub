// src/components/ui/CompanyAvatar.jsx
// ─── Company Initial Avatar ───────────────────────────────────
// Until companies can upload logos, show their initial on a colour
// picked from the name, so the same company always looks the same.

const COLORS = [
  "from-sky-500 to-blue-600",
  "from-violet-500 to-indigo-600",
  "from-emerald-500 to-teal-600",
  "from-amber-500 to-orange-600",
  "from-rose-500 to-pink-600",
  "from-cyan-500 to-sky-600",
];

const SIZES = {
  md: "w-11 h-11 text-base rounded-xl",
  lg: "w-14 h-14 text-xl rounded-2xl",
};

export default function CompanyAvatar({ name = "", size = "md" }) {
  const hash = [...name].reduce((sum, char) => sum + char.charCodeAt(0), 0);

  return (
    <span
      aria-hidden="true"
      className={`flex items-center justify-center shrink-0 font-bold text-white bg-linear-to-br ${COLORS[hash % COLORS.length]} ${SIZES[size]}`}
    >
      {name.trim().charAt(0).toUpperCase() || "?"}
    </span>
  );
}
